<?php $__env->startSection('header'); ?>


<main class="page">
    <div id="space"></div>
    <div class="row">
        <div class="col">
            <ul class="list-unstyled text-center">
                <li>Products we sell</li>
            </ul>
        </div>
    </div>
</main>
<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danhi\Desktop\ISAD251---Coursework\pub_site\resources\views/menu.blade.php ENDPATH**/ ?>