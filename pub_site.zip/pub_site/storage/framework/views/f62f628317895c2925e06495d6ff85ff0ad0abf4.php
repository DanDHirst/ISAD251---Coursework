<?php $__env->startSection('header'); ?>
    <main class="page">
        <div id="space"></div>
        <div class="row">
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6" id="navcol-1"><a class="btn btn-primary btn-lg" role="button" href="adminProducts">Drink and snack management</a></div>
            <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6"><a class="btn btn-primary btn-lg" role="button" href="adminCustomer">Customer Managment</a></div>
        </div>
    </main>
    <?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danhi\Desktop\ISAD251---Coursework\pub_site\resources\views/admin.blade.php ENDPATH**/ ?>