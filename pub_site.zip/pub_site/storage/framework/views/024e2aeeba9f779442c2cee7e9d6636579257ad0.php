<?php
    echo "Customer orders screen";
    ?>
<?php /**PATH C:\Users\danhi\Desktop\ISAD261---Coursework\pub_site\resources\views/customerOrders.blade.php ENDPATH**/ ?>