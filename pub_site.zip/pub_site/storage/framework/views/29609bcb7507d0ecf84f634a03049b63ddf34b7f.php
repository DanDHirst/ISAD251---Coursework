<?php
echo "admin orders";
?>
<?php /**PATH C:\Users\danhi\Desktop\ISAD261---Coursework\pub_site\resources\views/adminOrders.blade.php ENDPATH**/ ?>