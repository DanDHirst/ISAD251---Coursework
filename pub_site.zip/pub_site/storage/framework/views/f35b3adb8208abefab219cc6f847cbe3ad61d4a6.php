<?php $__env->startSection('header'); ?>

<h1>menu</h1>
<?php if(count($menu)): ?>
    <ul>
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($item); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\danhi\Desktop\ISAD261---Coursework\pub_site\resources\views/home.blade.php ENDPATH**/ ?>