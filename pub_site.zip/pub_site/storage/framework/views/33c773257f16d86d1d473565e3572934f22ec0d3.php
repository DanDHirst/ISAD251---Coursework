<?php
    echo "this is the order page";
    ?>
<?php /**PATH C:\Users\danhi\Desktop\ISAD261---Coursework\pub_site\resources\views/order.blade.php ENDPATH**/ ?>