<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GetSnack extends Model
{
    //
    protected $table = 'getsnacks';
    protected $primaryKey = 'ProdID';
}
