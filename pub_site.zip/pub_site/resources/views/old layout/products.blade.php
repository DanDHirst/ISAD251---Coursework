<?php
echo "admin product page";
?>
