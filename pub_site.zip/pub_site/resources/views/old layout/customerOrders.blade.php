<?php
    echo "Customer orders screen";
    ?>
