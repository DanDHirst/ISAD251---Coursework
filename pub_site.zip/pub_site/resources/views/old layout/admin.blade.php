<?php
    echo "This is the admin page";
    ?>
